<?php
/* Smarty version 4.1.0, created on 2022-05-25 10:53:03
  from 'C:\xampp\htdocs\SklepNB\templates\head.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.1.0',
  'unifunc' => 'content_628dee6f186124_60106532',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '603503d63cf0e69cb86ea144bc188910bac4516e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\SklepNB\\templates\\head.tpl',
      1 => 1653468776,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_628dee6f186124_60106532 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css.css">
    <title>NiezłeBenzo.pl</title>
</head>
<body>
    <h1>NiezłeBenzo.pl</h1>
    <h2>Sklep internetowy w którym kupisz wszytko i nic</h2>
    <div class="header">
        <a href="SronaG.php" class="headtext">HOME</a>
        <a href="Sklep.php" class="headtext">SKLEP ONLINE</a>
        <a href="#NOWOŚCI" class="headtext">NOWOŚCI</a>
        <a href="#SKLEP STACJONARNY" class="headtext">SKLEP STACJONARNY</a>
        <a href="#KONTAKT" class="headtext">KONTAKT</a>
        <a href="#O NAS" class="headtext">O NAS</a>
        <a href="logowanie.php" class="headtext">LOGOWANIE</a>
    </div>
<?php }
}
