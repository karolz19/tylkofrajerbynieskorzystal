    <?php
    require_once('config.php');

    $q = $db->prepare("SELECT * FROM produkty");

    if ($q && $q->execute()) {

        $result = $q->get_result();
        $produkty = array();
        while ($produkt = $result->fetch_assoc()) {

            $id = $produkt['id'];
            $nazwa = $produkt['nazwa'];
            $cena = $produkt['cena'];
            $zdj = $produkt['zdj'];
            $p = array(
                "id" => $id,
                "nazwa" => $nazwa,
                "cena" => $cena,
                "zdj" => $zdj
            );
            array_push($produkty, $p);
            /*
            echo "<div style=\"width:33%; height:30%; float: left\">";
            echo $produktynazwa;
            echo "<img src=\"$produktyzdj\">";
            echo $produktycena;
            echo "</div>";
            */
        }
        $smarty->assign("produkty", $produkty);
        $smarty->display("bebech.tpl");
        //echo "<a href=\"patientLogin.php?id=$appointmentId\" style=\"margin:10px; display:block\">";
    }
    ?>



    </body>

    </html>