<?php
require_once('config.php');
$smarty->display('head.tpl');
?>
    <div class="xd">
        <img src="png/TOP.png">
    </div>
